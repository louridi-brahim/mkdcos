---
title: "Est-il possible de créer des gabarits personnalisés sur la plateforme Cloud π ?"
date: "2023-06-20T15:18:56.000Z"
type: "post"
source: "elementor"
---

# Est-il possible de créer des gabarits personnalisés sur la plateforme Cloud π ?

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut at sapien et leo tristique viverra. Nullam vulputate ornare porttitor. Nulla facilisi. Suspendisse fringilla maximus justo non consequat. Aliquam auctor pellentesque est, nec posuere ligula elementum vel. Mauris magna neque, pellentesque eu iaculis nec, ultrices eget augue. Suspendisse rutrum ultricies purus interdum lobortis. Integer nisl odio, volutpat vel eleifend eget, sollicitudin sed lacus. Fusce at efficitur felis. Phasellus tincidunt dui nec semper efficitur. Phasellus sit amet lorem ligula. Fusce in fringilla neque. Proin tempor convallis orci vel blandit.

Fusce varius dui et rhoncus mattis. Cras ac ipsum dui. Vivamus aliquam nunc sem, sit amet finibus mauris rutrum hendrerit. In feugiat lacus non varius aliquam. Morbi scelerisque, risus at elementum dictum, lacus ex feugiat magna, auctor lobortis ligula ex quis ipsum. Mauris mattis semper nulla a sagittis. Mauris gravida ornare felis, sed consectetur velit dapibus ut. Etiam venenatis luctus tellus, in egestas purus blandit a. Nullam in orci lacinia, egestas quam in, mattis libero. Donec eu tellus nec ex vulputate tempor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam condimentum ipsum id metus luctus, et vestibulum ante gravida. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nam ac ligula volutpat, scelerisque dolor sed, condimentum neque.